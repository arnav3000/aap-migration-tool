#!/bin/bash
#
# Decrypt credentials file after secure transfer
#
# Usage: ./decrypt_credentials.sh [method] [input_file]
#   method: gpg (default) or base64
#   input_file: optional, defaults to credentials_decrypted.json.gpg or .b64
#
# Example:
#   ./decrypt_credentials.sh gpg
#   ./decrypt_credentials.sh base64
#   ./decrypt_credentials.sh gpg /path/to/encrypted_file.gpg
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
METHOD="${1:-gpg}"
OUTPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json"

# Determine input file
if [ -n "$2" ]; then
    INPUT_FILE="$2"
elif [ "$METHOD" == "gpg" ]; then
    INPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json.gpg"
elif [ "$METHOD" == "openssl" ]; then
    INPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json.enc"
else
    INPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json.b64"
fi

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Credential File Decryption${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo -e "${RED}ERROR: Input file not found: $INPUT_FILE${NC}"
    echo ""
    echo -e "${YELLOW}Looking for encrypted files in ${SCRIPT_DIR}:${NC}"
    ls -lh "${SCRIPT_DIR}"/*.gpg 2>/dev/null || echo "  No .gpg files found"
    ls -lh "${SCRIPT_DIR}"/*.b64 2>/dev/null || echo "  No .b64 files found"
    exit 1
fi

# Validate decryption method
if [ "$METHOD" != "gpg" ] && [ "$METHOD" != "base64" ] && [ "$METHOD" != "openssl" ]; then
    echo -e "${RED}ERROR: Invalid decryption method: $METHOD${NC}"
    echo -e "${YELLOW}Valid methods: openssl, gpg, base64${NC}"
    exit 1
fi

echo -e "${YELLOW}→${NC} Input file: ${INPUT_FILE}"
echo -e "${YELLOW}→${NC} Decryption method: ${METHOD}"
echo -e "${YELLOW}→${NC} Output file: ${OUTPUT_FILE}"
echo ""

# Check if output file already exists
if [ -f "$OUTPUT_FILE" ]; then
    echo -e "${YELLOW}⚠️  Warning: Output file already exists!${NC}"
    echo -e "${YELLOW}   ${OUTPUT_FILE}${NC}"
    read -p "Overwrite? (yes/no): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Cancelled."
        exit 0
    fi
fi

if [ "$METHOD" == "openssl" ]; then
    # OpenSSL Decryption
    echo -e "${BLUE}Using OpenSSL AES-256-CBC decryption${NC}"
    echo -e "${YELLOW}You will be prompted to enter the passphrase${NC}"
    echo ""

    # Check if openssl is available
    if ! command -v openssl &> /dev/null; then
        echo -e "${RED}ERROR: openssl command not found${NC}"
        exit 1
    fi

    # Decrypt with OpenSSL
    if openssl enc -aes-256-cbc -d -pbkdf2 -in "$INPUT_FILE" -out "$OUTPUT_FILE"; then
        echo ""
        echo -e "${GREEN}✓${NC} File decrypted successfully!"
        echo -e "${GREEN}→${NC} Decrypted file: ${OUTPUT_FILE}"

        # Verify it's valid JSON
        echo ""
        echo -e "${YELLOW}Verifying JSON format...${NC}"
        if command -v jq &> /dev/null; then
            if jq empty "$OUTPUT_FILE" 2>/dev/null; then
                echo -e "${GREEN}✓${NC} Valid JSON file"

                # Show summary
                CRED_COUNT=$(jq -r '.metadata.total_credentials // 0' "$OUTPUT_FILE")
                echo ""
                echo -e "${BLUE}Credentials Summary:${NC}"
                echo -e "  Total credentials: ${GREEN}${CRED_COUNT}${NC}"

                # Show first few credential names
                echo -e "  First 5 credentials:"
                jq -r '.credentials[0:5] | .[] | "    - \(.name) (\(.credential_type))"' "$OUTPUT_FILE"
            else
                echo -e "${RED}⚠${NC} Warning: File is not valid JSON"
            fi
        else
            echo -e "${YELLOW}  (install jq to verify JSON format)${NC}"
        fi

    else
        echo -e "${RED}✗${NC} Decryption failed!"
        echo -e "${YELLOW}Common issues:${NC}"
        echo -e "  - Wrong passphrase"
        echo -e "  - File corrupted during transfer"
        echo -e "  - Wrong encryption method"
        exit 1
    fi

elif [ "$METHOD" == "gpg" ]; then
    # GPG Decryption
    echo -e "${BLUE}Using GPG decryption${NC}"
    echo -e "${YELLOW}You will be prompted to enter the passphrase${NC}"
    echo ""

    # Check if gpg is available
    if ! command -v gpg &> /dev/null; then
        echo -e "${RED}ERROR: gpg command not found${NC}"
        echo -e "${YELLOW}Install GPG:${NC}"
        echo -e "  RHEL/CentOS: sudo yum install gnupg"
        echo -e "  Ubuntu:      sudo apt install gnupg"
        echo -e "  macOS:       brew install gnupg"
        exit 1
    fi

    # Decrypt with GPG
    if gpg --decrypt --output "$OUTPUT_FILE" "$INPUT_FILE"; then
        echo ""
        echo -e "${GREEN}✓${NC} File decrypted successfully!"
        echo -e "${GREEN}→${NC} Decrypted file: ${OUTPUT_FILE}"

        # Verify it's valid JSON
        echo ""
        echo -e "${YELLOW}Verifying JSON format...${NC}"
        if command -v jq &> /dev/null; then
            if jq empty "$OUTPUT_FILE" 2>/dev/null; then
                echo -e "${GREEN}✓${NC} Valid JSON file"

                # Show summary
                CRED_COUNT=$(jq -r '.metadata.total_credentials // 0' "$OUTPUT_FILE")
                echo ""
                echo -e "${BLUE}Credentials Summary:${NC}"
                echo -e "  Total credentials: ${GREEN}${CRED_COUNT}${NC}"

                # Show first few credential names
                echo -e "  First 5 credentials:"
                jq -r '.credentials[0:5] | .[] | "    - \(.name) (\(.credential_type))"' "$OUTPUT_FILE"
            else
                echo -e "${RED}⚠${NC} Warning: File is not valid JSON"
            fi
        else
            echo -e "${YELLOW}  (install jq to verify JSON format)${NC}"
        fi

    else
        echo -e "${RED}✗${NC} Decryption failed!"
        echo -e "${YELLOW}Common issues:${NC}"
        echo -e "  - Wrong passphrase"
        echo -e "  - File corrupted during transfer"
        echo -e "  - Wrong encryption method"
        exit 1
    fi

elif [ "$METHOD" == "base64" ]; then
    # Base64 Decoding
    echo -e "${YELLOW}→${NC} Decoding file with base64..."

    if base64 --decode "$INPUT_FILE" > "$OUTPUT_FILE"; then
        echo -e "${GREEN}✓${NC} File decoded successfully!"
        echo -e "${GREEN}→${NC} Decoded file: ${OUTPUT_FILE}"

        # Verify it's valid JSON
        echo ""
        echo -e "${YELLOW}Verifying JSON format...${NC}"
        if command -v jq &> /dev/null; then
            if jq empty "$OUTPUT_FILE" 2>/dev/null; then
                echo -e "${GREEN}✓${NC} Valid JSON file"

                # Show summary
                CRED_COUNT=$(jq -r '.metadata.total_credentials // 0' "$OUTPUT_FILE")
                echo ""
                echo -e "${BLUE}Credentials Summary:${NC}"
                echo -e "  Total credentials: ${GREEN}${CRED_COUNT}${NC}"
            else
                echo -e "${RED}⚠${NC} Warning: File is not valid JSON"
            fi
        fi
    else
        echo -e "${RED}✗${NC} Decoding failed!"
        exit 1
    fi
fi

# Set restrictive permissions
chmod 400 "$OUTPUT_FILE"
echo ""
echo -e "${GREEN}✓${NC} Set permissions to 400 (read-only for owner)"

# Security recommendations
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Security Reminders${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${YELLOW}⚠️  The decrypted file contains REAL SECRETS!${NC}"
echo ""
echo -e "${GREEN}1. Use the file for migration:${NC}"
echo -e "   - Reference credentials when importing to AAP 2.6"
echo -e "   - Update credentials with real secret values"
echo ""
echo -e "${GREEN}2. After migration, SECURELY DELETE:${NC}"
echo -e "   ${RED}shred -u ${OUTPUT_FILE}${NC}"
echo -e "   (Use shred, not just rm)"
echo ""
echo -e "${GREEN}3. Optionally delete the encrypted file too:${NC}"
echo -e "   ${RED}shred -u ${INPUT_FILE}${NC}"
echo ""
echo -e "${YELLOW}⚠️  Do NOT commit this file to git!${NC}"
echo -e "${YELLOW}   (.gitignore already configured to prevent this)${NC}"
echo ""
