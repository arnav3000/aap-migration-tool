#!/bin/bash
#
# Encrypt credentials file for secure transfer
#
# Usage: ./encrypt_credentials.sh [method]
#   method: gpg (default) or base64
#
# Example:
#   ./encrypt_credentials.sh gpg
#   ./encrypt_credentials.sh base64
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json"
METHOD="${1:-gpg}"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Credential File Encryption${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo -e "${RED}ERROR: Input file not found: $INPUT_FILE${NC}"
    echo -e "${YELLOW}Run ./run_extraction.sh first to create the credentials file${NC}"
    exit 1
fi

# Validate encryption method
if [ "$METHOD" != "gpg" ] && [ "$METHOD" != "base64" ] && [ "$METHOD" != "openssl" ]; then
    echo -e "${RED}ERROR: Invalid encryption method: $METHOD${NC}"
    echo -e "${YELLOW}Valid methods: openssl (recommended), gpg, base64${NC}"
    exit 1
fi

echo -e "${YELLOW}→${NC} Input file: ${INPUT_FILE}"
echo -e "${YELLOW}→${NC} Encryption method: ${METHOD}"
echo ""

if [ "$METHOD" == "openssl" ]; then
    # OpenSSL Encryption (Recommended - Simple and reliable)
    OUTPUT_FILE="${INPUT_FILE}.enc"

    echo -e "${BLUE}Using OpenSSL AES-256-CBC encryption${NC}"
    echo -e "${YELLOW}You will be prompted to enter a passphrase${NC}"
    echo -e "${YELLOW}⚠️  Remember this passphrase - you'll need it to decrypt!${NC}"
    echo ""

    # Check if openssl is available
    if ! command -v openssl &> /dev/null; then
        echo -e "${RED}ERROR: openssl command not found${NC}"
        exit 1
    fi

    # Encrypt with OpenSSL (AES-256-CBC)
    if openssl enc -aes-256-cbc -salt -pbkdf2 -in "$INPUT_FILE" -out "$OUTPUT_FILE"; then
        echo ""
        echo -e "${GREEN}✓${NC} File encrypted successfully!"
        echo -e "${GREEN}→${NC} Encrypted file: ${OUTPUT_FILE}"

        # Show file size
        INPUT_SIZE=$(du -h "$INPUT_FILE" | cut -f1)
        OUTPUT_SIZE=$(du -h "$OUTPUT_FILE" | cut -f1)
        echo ""
        echo -e "${BLUE}File sizes:${NC}"
        echo -e "  Original:  ${INPUT_SIZE}"
        echo -e "  Encrypted: ${OUTPUT_SIZE}"

        # Set restrictive permissions
        chmod 400 "$OUTPUT_FILE"
        echo ""
        echo -e "${GREEN}✓${NC} Set file permissions to 400 (read-only for owner)"

    else
        echo -e "${RED}✗${NC} Encryption failed!"
        exit 1
    fi

elif [ "$METHOD" == "gpg" ]; then
    # GPG Encryption (Recommended - Strong encryption)
    OUTPUT_FILE="${INPUT_FILE}.gpg"

    echo -e "${BLUE}Using GPG symmetric encryption (AES256)${NC}"
    echo -e "${YELLOW}You will be prompted to enter a passphrase${NC}"
    echo -e "${YELLOW}⚠️  Remember this passphrase - you'll need it to decrypt!${NC}"
    echo ""

    # Check if gpg is available
    if ! command -v gpg &> /dev/null; then
        echo -e "${RED}ERROR: gpg command not found${NC}"
        echo -e "${YELLOW}Install GPG:${NC}"
        echo -e "  RHEL/CentOS: sudo yum install gnupg"
        echo -e "  Ubuntu:      sudo apt install gnupg"
        echo -e "  macOS:       brew install gnupg"
        exit 1
    fi

    # Encrypt with GPG (symmetric encryption, AES256 cipher)
    if gpg --symmetric --cipher-algo AES256 --armor --output "$OUTPUT_FILE" "$INPUT_FILE"; then
        echo ""
        echo -e "${GREEN}✓${NC} File encrypted successfully!"
        echo -e "${GREEN}→${NC} Encrypted file: ${OUTPUT_FILE}"

        # Show file size
        INPUT_SIZE=$(du -h "$INPUT_FILE" | cut -f1)
        OUTPUT_SIZE=$(du -h "$OUTPUT_FILE" | cut -f1)
        echo ""
        echo -e "${BLUE}File sizes:${NC}"
        echo -e "  Original:  ${INPUT_SIZE}"
        echo -e "  Encrypted: ${OUTPUT_SIZE}"

        # Verify encryption worked
        echo ""
        echo -e "${YELLOW}Verifying encryption...${NC}"
        if file "$OUTPUT_FILE" | grep -q "PGP"; then
            echo -e "${GREEN}✓${NC} File is properly encrypted (PGP/GPG format)"
        else
            echo -e "${RED}⚠${NC} Warning: File format verification failed"
        fi

    else
        echo -e "${RED}✗${NC} Encryption failed!"
        exit 1
    fi

elif [ "$METHOD" == "base64" ]; then
    # Base64 Encoding (Simple obfuscation, NOT real encryption)
    OUTPUT_FILE="${INPUT_FILE}.b64"

    echo -e "${YELLOW}⚠️  WARNING: Base64 is ENCODING, not encryption!${NC}"
    echo -e "${YELLOW}   It only obfuscates data - anyone can decode it${NC}"
    echo -e "${YELLOW}   Use GPG for real security${NC}"
    echo ""
    read -p "Continue with base64? (yes/no): " confirm

    if [ "$confirm" != "yes" ]; then
        echo "Cancelled."
        exit 0
    fi

    echo -e "${YELLOW}→${NC} Encoding file with base64..."

    if base64 "$INPUT_FILE" > "$OUTPUT_FILE"; then
        echo -e "${GREEN}✓${NC} File encoded successfully!"
        echo -e "${GREEN}→${NC} Encoded file: ${OUTPUT_FILE}"

        # Show file size
        INPUT_SIZE=$(du -h "$INPUT_FILE" | cut -f1)
        OUTPUT_SIZE=$(du -h "$OUTPUT_FILE" | cut -f1)
        echo ""
        echo -e "${BLUE}File sizes:${NC}"
        echo -e "  Original: ${INPUT_SIZE}"
        echo -e "  Encoded:  ${OUTPUT_SIZE}"
    else
        echo -e "${RED}✗${NC} Encoding failed!"
        exit 1
    fi
fi

# Security recommendations
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Next Steps${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${GREEN}1. Transfer the encrypted file:${NC}"
echo -e "   scp ${OUTPUT_FILE} user@workstation:/destination/"
echo ""
echo -e "${GREEN}2. Delete the unencrypted original:${NC}"
echo -e "   ${RED}shred -u ${INPUT_FILE}${NC}"
echo -e "   (Use shred to securely delete, not just rm)"
echo ""
echo -e "${GREEN}3. On receiving system, decrypt with:${NC}"
if [ "$METHOD" == "gpg" ]; then
    echo -e "   ./decrypt_credentials.sh gpg"
elif [ "$METHOD" == "openssl" ]; then
    echo -e "   ./decrypt_credentials.sh openssl"
else
    echo -e "   ./decrypt_credentials.sh base64"
fi
echo ""
echo -e "${YELLOW}⚠️  Keep the passphrase/method secure!${NC}"
echo ""
