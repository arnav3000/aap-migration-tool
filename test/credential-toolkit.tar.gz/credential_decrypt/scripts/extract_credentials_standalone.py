#!/usr/bin/env python3
"""
Standalone credential extraction script for AAP 2.4

This script can be run directly:
    python3 extract_credentials_standalone.py

Or via awx-manage:
    awx-manage shell < extract_credentials_standalone.py
"""

import os
import sys
import json
from datetime import datetime

# Initialize Django FIRST before any AWX imports
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'awx.settings.production')

try:
    import django
    django.setup()
except Exception as e:
    # If Django setup fails, we're probably already in awx-manage shell context
    # where Django is already initialized
    pass

# NOW import AWX models and utilities (after Django is ready)
from awx.main.models import Credential, CredentialType, Organization
from awx.main.utils import decrypt_field


def get_encrypted_fields(credential_type):
    """
    Get list of encrypted field names for a credential type.
    """
    encrypted_fields = []

    if not credential_type or not hasattr(credential_type, 'inputs'):
        return encrypted_fields

    inputs_schema = credential_type.inputs.get('fields', [])

    for field in inputs_schema:
        # Fields marked as secret need decryption
        if field.get('secret', False):
            encrypted_fields.append(field['id'])

    return encrypted_fields


def extract_all_credentials():
    """
    Extract and decrypt all credentials.
    """
    print("=" * 80, file=sys.stderr)
    print("AAP 2.4 Credential Extraction & Decryption", file=sys.stderr)
    print("=" * 80, file=sys.stderr)
    print(f"Started: {datetime.now().isoformat()}", file=sys.stderr)
    print("", file=sys.stderr)

    # Initialize results
    results = {
        "metadata": {
            "extraction_date": datetime.now().isoformat(),
            "source_system": "AAP 2.4"
        },
        "credentials": []
    }

    try:
        # Get all credentials
        all_credentials = Credential.objects.all().select_related(
            'credential_type', 'organization'
        )

        total_count = all_credentials.count()
        results["metadata"]["total_credentials"] = total_count

        print(f"Found {total_count} credentials", file=sys.stderr)
        print("", file=sys.stderr)

        processed = 0
        errors = 0

        for cred in all_credentials:
            try:
                processed += 1

                # Get credential type
                cred_type = cred.credential_type
                cred_type_name = cred_type.name if cred_type else "Unknown"
                cred_type_kind = cred_type.kind if cred_type else "unknown"
                cred_type_id = cred_type.id if cred_type else None

                # Get organization
                org = cred.organization
                org_name = org.name if org else None
                org_id = org.id if org else None

                print(f"[{processed}/{total_count}] {cred.name} (ID: {cred.id}, Type: {cred_type_name})", file=sys.stderr)

                # Get encrypted field names
                encrypted_field_names = get_encrypted_fields(cred_type)

                # Start with current inputs
                decrypted_inputs = {}
                if hasattr(cred, 'inputs') and cred.inputs:
                    decrypted_inputs = dict(cred.inputs)

                # Decrypt each field
                for field_name in encrypted_field_names:
                    if field_name in decrypted_inputs:
                        try:
                            decrypted_value = decrypt_field(cred, field_name)
                            if decrypted_value:
                                decrypted_inputs[field_name] = decrypted_value
                                print(f"  ✓ Decrypted: {field_name}", file=sys.stderr)
                        except Exception as e:
                            print(f"  ⚠ Warning: {field_name}: {e}", file=sys.stderr)

                # Build credential object
                cred_data = {
                    "id": cred.id,
                    "name": cred.name,
                    "description": cred.description or "",
                    "credential_type": cred_type_name,
                    "credential_type_id": cred_type_id,
                    "credential_type_kind": cred_type_kind,
                    "organization": org_name,
                    "organization_id": org_id,
                    "inputs": decrypted_inputs,
                    "created": cred.created.isoformat() if hasattr(cred, 'created') else None,
                    "modified": cred.modified.isoformat() if hasattr(cred, 'modified') else None
                }

                results["credentials"].append(cred_data)

            except Exception as e:
                errors += 1
                print(f"  ✗ ERROR: {e}", file=sys.stderr)
                import traceback
                traceback.print_exc(file=sys.stderr)
                continue

        # Update metadata
        results["metadata"]["processed_count"] = processed - errors
        results["metadata"]["error_count"] = errors

        # Summary
        print("", file=sys.stderr)
        print("=" * 80, file=sys.stderr)
        print("Summary", file=sys.stderr)
        print("=" * 80, file=sys.stderr)
        print(f"Total: {total_count}", file=sys.stderr)
        print(f"Processed: {processed - errors}", file=sys.stderr)
        print(f"Errors: {errors}", file=sys.stderr)
        print(f"Completed: {datetime.now().isoformat()}", file=sys.stderr)
        print("", file=sys.stderr)

        # Output JSON to stdout
        print(json.dumps(results, indent=2))

        return 0

    except Exception as e:
        print(f"FATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return 1


# Execute unconditionally - works in all contexts
# (direct execution, awx-python, awx-manage shell)
extract_all_credentials()
