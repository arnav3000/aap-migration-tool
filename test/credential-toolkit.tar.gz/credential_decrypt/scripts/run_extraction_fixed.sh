#!/bin/bash
#
# Fixed credential extraction script
# Tries multiple execution methods to ensure compatibility
#
# Usage: ./run_extraction_fixed.sh
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXTRACT_SCRIPT="${SCRIPT_DIR}/extract_credentials_standalone.py"
OUTPUT_FILE="${SCRIPT_DIR}/credentials_decrypted.json"
LOG_FILE="${SCRIPT_DIR}/extraction.log"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}AAP 2.4 Credential Extraction (Fixed)${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if running on AAP controller
if ! command -v awx-manage &> /dev/null; then
    echo -e "${RED}ERROR: awx-manage command not found${NC}"
    echo -e "${RED}This script must be run ON the AAP 2.4 controller node${NC}"
    exit 1
fi

# Check if extraction script exists
if [ ! -f "$EXTRACT_SCRIPT" ]; then
    echo -e "${RED}ERROR: Extraction script not found: $EXTRACT_SCRIPT${NC}"
    exit 1
fi

echo -e "${YELLOW}→${NC} Extraction script: $EXTRACT_SCRIPT"
echo -e "${YELLOW}→${NC} Output file: $OUTPUT_FILE"
echo ""
echo -e "${YELLOW}→${NC} Trying execution methods (best to worst)..."
echo ""

# METHOD 1: Via awx-python (PREFERRED - has full AWX environment)
echo -e "${BLUE}Method 1: awx-python (preferred)${NC}"
if command -v awx-python &> /dev/null; then
    if awx-python "$EXTRACT_SCRIPT" > "$OUTPUT_FILE" 2> "$LOG_FILE"; then
        echo -e "${GREEN}✓${NC} Method 1 succeeded!"
        METHOD="awx-python"
    elif [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
        echo -e "${GREEN}✓${NC} Method 1 succeeded (with warnings)!"
        METHOD="awx-python"
    else
        echo -e "${YELLOW}→${NC} Method 1 failed, trying Method 2..."
        echo ""

        # METHOD 2: Via awx-manage shell (non-interactive)
        echo -e "${BLUE}Method 2: awx-manage shell${NC}"
        if cat "$EXTRACT_SCRIPT" | awx-manage shell > "$OUTPUT_FILE" 2> "$LOG_FILE"; then
            echo -e "${GREEN}✓${NC} Method 2 succeeded!"
            METHOD="awx-manage-shell"
        elif [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
            echo -e "${GREEN}✓${NC} Method 2 succeeded (with warnings)!"
            METHOD="awx-manage-shell"
        else
            echo -e "${YELLOW}→${NC} Method 2 failed, trying Method 3..."
            echo ""

            # METHOD 3: Direct Python execution (rarely works)
            echo -e "${BLUE}Method 3: Direct Python execution${NC}"
            if python3 "$EXTRACT_SCRIPT" > "$OUTPUT_FILE" 2> "$LOG_FILE"; then
                echo -e "${GREEN}✓${NC} Method 3 succeeded!"
                METHOD="direct-python"
            elif [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
                echo -e "${GREEN}✓${NC} Method 3 succeeded (with warnings)!"
                METHOD="direct-python"
            else
                echo -e "${RED}✗${NC} All methods failed!"
                echo ""
                echo -e "${RED}Last error from log file:${NC}"
                tail -30 "$LOG_FILE"
                exit 1
            fi
        fi
    fi
else
    echo -e "${YELLOW}→${NC} awx-python not available, trying Method 2..."
    echo ""

    # METHOD 2: Via awx-manage shell (non-interactive)
    echo -e "${BLUE}Method 2: awx-manage shell${NC}"
    if cat "$EXTRACT_SCRIPT" | awx-manage shell > "$OUTPUT_FILE" 2> "$LOG_FILE"; then
        echo -e "${GREEN}✓${NC} Method 2 succeeded!"
        METHOD="awx-manage-shell"
    elif [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
        echo -e "${GREEN}✓${NC} Method 2 succeeded (with warnings)!"
        METHOD="awx-manage-shell"
    else
        echo -e "${YELLOW}→${NC} Method 2 failed, trying Method 3..."
        echo ""

        # METHOD 3: Direct Python execution (rarely works)
        echo -e "${BLUE}Method 3: Direct Python execution${NC}"
        if python3 "$EXTRACT_SCRIPT" > "$OUTPUT_FILE" 2> "$LOG_FILE"; then
            echo -e "${GREEN}✓${NC} Method 3 succeeded!"
            METHOD="direct-python"
        elif [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
            echo -e "${GREEN}✓${NC} Method 3 succeeded (with warnings)!"
            METHOD="direct-python"
        else
            echo -e "${RED}✗${NC} All available methods failed!"
            echo ""
            echo -e "${RED}Last error from log file:${NC}"
            tail -30 "$LOG_FILE"
            exit 1
        fi
    fi
fi

# Validate output
if [ ! -f "$OUTPUT_FILE" ] || [ ! -s "$OUTPUT_FILE" ]; then
    echo -e "${RED}✗${NC} Output file is empty or missing!"
    echo -e "${RED}Check log: $LOG_FILE${NC}"
    tail -30 "$LOG_FILE"
    exit 1
fi

# Validate JSON
if ! python3 -m json.tool "$OUTPUT_FILE" > /dev/null 2>&1; then
    echo -e "${RED}✗${NC} Output is not valid JSON!"
    echo -e "${RED}First 20 lines of output:${NC}"
    head -20 "$OUTPUT_FILE"
    exit 1
fi

echo ""
echo -e "${GREEN}✓ Extraction completed successfully using: ${METHOD}${NC}"
echo ""

# Parse results
if command -v jq &> /dev/null; then
    CRED_COUNT=$(jq -r '.metadata.processed_count // 0' "$OUTPUT_FILE" 2>/dev/null)
    ERROR_COUNT=$(jq -r '.metadata.error_count // 0' "$OUTPUT_FILE" 2>/dev/null)
    TOTAL_COUNT=$(jq -r '.metadata.total_credentials // 0' "$OUTPUT_FILE" 2>/dev/null)
else
    CRED_COUNT=$(python3 -c "import json; print(json.load(open('$OUTPUT_FILE'))['metadata'].get('processed_count', 0))" 2>/dev/null || echo "unknown")
    ERROR_COUNT=$(python3 -c "import json; print(json.load(open('$OUTPUT_FILE'))['metadata'].get('error_count', 0))" 2>/dev/null || echo "0")
    TOTAL_COUNT=$(python3 -c "import json; print(json.load(open('$OUTPUT_FILE'))['metadata'].get('total_credentials', 0))" 2>/dev/null || echo "unknown")
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Results${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "  Total credentials: ${TOTAL_COUNT}"
echo -e "  Successfully extracted: ${GREEN}${CRED_COUNT}${NC}"
echo -e "  Errors: ${RED}${ERROR_COUNT}${NC}"
echo ""
echo -e "${BLUE}Output files:${NC}"
echo -e "  JSON: ${GREEN}${OUTPUT_FILE}${NC}"
echo -e "  Logs: ${YELLOW}${LOG_FILE}${NC}"
echo ""

# Show sample if jq available
if command -v jq &> /dev/null; then
    echo -e "${BLUE}First credential (sample):${NC}"
    jq -r '.credentials[0] | {id, name, credential_type, organization}' "$OUTPUT_FILE" 2>/dev/null || true
    echo ""
fi

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}IMPORTANT - Next Steps:${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}1. ENCRYPT IMMEDIATELY (MANDATORY!):${NC}"
echo -e "   ./encrypt_credentials.sh gpg"
echo ""
echo -e "${YELLOW}2. DELETE UNENCRYPTED FILE:${NC}"
echo -e "   shred -u $OUTPUT_FILE"
echo ""
echo -e "${YELLOW}3. TRANSFER ENCRYPTED FILE:${NC}"
echo -e "   scp ${OUTPUT_FILE}.gpg user@workstation:/path/"
echo ""
echo -e "${RED}⚠️  WARNING: File contains UNENCRYPTED SECRETS!${NC}"
echo -e "${RED}   Encrypt it NOW before doing anything else!${NC}"
echo ""
